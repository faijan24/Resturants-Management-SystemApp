package Com.Model;

public class Customer {

	private int cid;
	private String cname;
	private int cconatact;
	private int cpass;

	public Customer(int cid, String cname, int cconatct, int cpass) {
		this.cid = cid;
		this.cname = cname;
		this.cconatact = cconatct;
		this.cpass = cpass;

	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getCconatact() {
		return cconatact;
	}

	public void setCconatact(int cconatact) {
		this.cconatact = cconatact;
	}

	public int getCpass() {
		return cpass;
	}

	public void setCpass(int cpass) {
		this.cpass = cpass;
	}

}
