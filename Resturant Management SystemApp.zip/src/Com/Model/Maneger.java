package Com.Model;

public class Maneger {
	private int mid;
	private String mname;
	private int mconatact;
	private int mpass;

	public Maneger(int mid, String mname, int mconatct, int mpass) {
		this.mid = mid;
		this.mname = mname;
		this.mconatact = mconatct;
		this.mpass = mpass;

	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public int getMconatact() {
		return mconatact;
	}

	public void setMconatact(int mconatact) {
		this.mconatact = mconatact;
	}

	public int getMpass() {
		return mpass;
	}

	public void setMpass(int mpass) {
		this.mpass = mpass;
	}


}
