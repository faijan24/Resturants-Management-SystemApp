package Com.cilentApp;

import java.util.*;

import Com.repositry_midApp.AddApp;

import java.util.*;

public class ResturantApp {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Vector v = new Vector();
		AddApp ad = new AddApp();

		int ch;

		do {
			// **Main Login**

			System.out.println("1.Login here ");
			System.out.println("2.Resister Here :");
			System.out.println("Enter your choice :");
			ch = sc.nextInt();

			switch (ch) {
			case 1:
				int ch2;
				// ** Login Details **

				System.out.println("1. Login For Maneger");
				System.out.println("2. Login For Customer");
				System.out.println("Enter Your Choice ");
				ch2 = sc.nextInt();

				switch (ch2) {
				case 1:

					// ** Maneger login And Details **

					if (ad.AddLogManeger()) {

						int ch3;
						do {
							System.out.println("1.Add Food Iteam");
							System.out.println("2.Display Food Iteam");
							System.out.println("3.Update Food Iteam");
							System.out.println("4.Delete Food Iteam");
							System.out.println("5.Display Toatal Sales");
							System.out.println("6.Display All Customer Details");
							System.out.println("Enter Your Choice");
							ch3 = sc.nextInt();

							switch (ch3) {

							case 1:
								ad.AddFoodIteam();
								break;

							case 2:

								ad.DisplayFoodIteam();
								break;

							case 3:

								ad.UpadteFoodIteam();
								break;

							case 4:

								ad.DeleteFoodIteam();
								break;

							case 5:
								ad.DisplayAllSales();
								break;

							case 6:
								ad.DisplayCustomerDetails();
								break;

							}

						} while (ch3 != 0);

					}
					break;

				case 2:

					// ** Coustomer Login And Details **

					if (ad.AddLogCustomer()) {
						int ch4;
						do {
							System.out.println("1.Display Food Iteam");
							System.out.println("2.Purchas Food Iteam");
							System.out.println("3.Display Total Bill");
							System.out.println("4.Serach Food Iteam Between Price Range");
							System.out.println("5.Serach Food Iteam By Categary");
							System.out.println("Enter Your Choice");
							ch4 = sc.nextInt();

							switch (ch4) {

							case 1:
								ad.DisplayFoodIteam();
								break;

							case 2:
								ad.AddPurchasFoodIteam();
								break;

							case 3:
								ad.TotalBill();
								break;

							case 4:
								ad.PriceRangeFood();
								break;

							case 5:
								ad.FoodIteamCategary();
								break;

							}

						} while (ch4 != 0);

					}
					break;
				}

				break;

			case 2:

				// ** Reisteration Details **

				System.out.println("A.User Type is Maneger ");
				System.out.println("B User Type is Customer");
				System.out.println("Select the one option ");
				char ch1 = sc.next().charAt(0);

				switch (ch1) {
				case 'A':
					ad.AddManeger();

					break;

				case 'B':
					ad.AddCustomer();

					break;

				}

				break;

			}

		} while (ch != 0);

	}

}
