package Com.repositry_midApp;

import java.util.*;

import Com.Model.Customer;
import Com.Model.Food;
import Com.Model.Maneger;

public class AddApp {

	ArrayList al = new ArrayList();
	Vector v1 = new Vector();
	Vector v2 = new Vector();
	ArrayList BillColl = new ArrayList();
	int Tbill;

	Scanner sc = new Scanner(System.in);

	Customer c;
	Maneger m;

	public void AddUser(Customer c, Maneger m) {

		this.c = c;
		this.m = m;
		;
	}

	// Add the Custmer Details

	public void AddCustomer() {

		System.out.println("Enter the Login id Customer");
		int id = sc.nextInt();

		System.out.println("Enter the  Name Customer");
		String Name = sc.next();

		System.out.println("Enter the Password Customer ");
		int Pass = sc.nextInt();

		System.out.println("Enter the Contact Customer ");
		int Contact = sc.nextInt();

		Customer c = new Customer(id, Name, Contact, Pass);

		boolean b = v1.add(c);
		if (b) {
			System.out.println("Resistertion Succesful");
		} else {
			System.out.println(" plz Resistertion again");
		}

	}

	// Add Manegers Details

	public void AddManeger() {
		System.out.println("Enter the Login id Maneger");
		int mid = sc.nextInt();

		System.out.println("Enter the  Name Maneger");
		String mName = sc.next();

		System.out.println("Enter the Password Maneger ");
		int mPass = sc.nextInt();

		System.out.println("Enter the Contact Maneger ");
		int mContact = sc.nextInt();

		Maneger m = new Maneger(mid, mName, mContact, mPass);

		boolean b = v2.add(m);
		if (b) {
			System.out.println("Resistertion Succesful");
		} else {
			System.out.println(" plz Resistertion again");
		}

	}

	// Login Details Of Manegers

	public boolean AddLogManeger() {

		System.out.println("Enter your Login Details : ");

		System.out.println("Enter Login id");
		int Lid = sc.nextInt();
		System.out.println("Enter Login Password");
		int Lpass = sc.nextInt();

		boolean b = v2.contains(m);
		for (Object obj : v2) {

			Maneger m = (Maneger) obj;

			if (Lid == m.getMid() && Lpass == m.getMpass()) {
				b = true;
			}

		}
		if (b) {
			System.out.println("Login Done");

		} else {
			System.out.println("Resisteration First :");
		}
		return b;

	}

	// Login Details Of Customers

	public boolean AddLogCustomer() {

		System.out.println("Enter your Login Details : ");

		System.out.println("Enter Login id");
		int Lid = sc.nextInt();
		System.out.println("Enter Login Password");
		int Lpass = sc.nextInt();

		boolean b = v1.contains(c);
		for (Object obj : v1) {

			Customer c = (Customer) obj;

			if (Lid == c.getCid() && Lpass == c.getCpass()) {
				b = true;
			}

		}
		if (b) {
			System.out.println("Login Done;");
		} else {
			System.out.println("Resisteration First :");
		}
		return b;

	}

	// Add Food Iteam

	public void AddFoodIteam() {

		System.out.println("Enter the Food Iteam size ");
		int size = sc.nextInt();
		Food f[] = new Food[size];

		for (int i = 0; i < f.length; i++) {

			System.out.println("Enter food Id");
			int id = sc.nextInt();
			System.out.println("Enter food Name ");
			String name = sc.next();

			System.out.println("Enter food Price ");
			int price = sc.nextInt();
			System.out.println("Enter food Category");
			String category = sc.next();

			f[i] = new Food(id, name, price, category);

			al.add(f[i]);

		}

	}

	// Display All Food is Here

	public void DisplayFoodIteam() {

		System.out.println("Display Food Iteam is :");

		Iterator itr = al.iterator();

		System.out.println("Id" + "\t" + "Name" + "\t" + "Price" + "\t");
		while (itr.hasNext()) {
			Object obj = itr.next();

			Food f1 = (Food) obj;
			System.out.println(f1.getId() + "\t" + f1.getName() + "\t" + f1.getPrice() + "\t" + f1.getCategory());

		}

	}

	// Update Food Iteam

	public void UpadteFoodIteam() {

		System.out.println("Enter id to Upate Food Iteam");
		int Sid = sc.nextInt();

		boolean b1 = false;
		for (Object obj : al) {
			Food f1 = (Food) obj;
			if (Sid == (int) f1.getId()) {

				System.out.println("Enter Chnage iteam name");
				String name = sc.next();

				System.out.println("Enter Chnage Price");
				int price = sc.nextInt();

				f1.setName(name);
				f1.setPrice(price);
				b1 = true;
			}

		}
		if (b1) {
			System.out.println("Update Success");

		} else {
			System.out.println("Not Upadte ");
		}

	}

	// Delete Food Iteam

	public void DeleteFoodIteam() {

		System.out.println("Enter The id To delete the Food Iteam");
		int Did = sc.nextInt();
		Iterator itr1 = al.iterator();
		boolean b2 = false;
		while (itr1.hasNext()) {
			Object obj = itr1.next();
			Food f2 = (Food) obj;

			if (Did == f2.getId()) {
				itr1.remove();
				b2 = true;
				break;

			}

		}

		if (b2) {
			System.out.println("Delete Food Iteam is Done");
		} else {
			System.out.println("Not Delete Food Iteam");
		}

	}

	// Display Toatal Sales

	public void DisplayAllSales() {

		int Tsale = 0;
		for (Object obj : BillColl) {
			int bill = (int) obj;
			Tsale = Tsale + bill;

		}
		System.out.println("Total Sale is:" + Tsale);

	}

	// Display All Customer Details
	public void DisplayCustomerDetails() {
		System.out.println("Id" + "\t" + "Name" + "\t" + "Conatct" + "\t" + "Password");
		for (Object obj1 : v1) {
			Customer c = (Customer) obj1;

			System.out.println(c.getCid() + "\t" + c.getCname() + "\t" + c.getCconatact() + "\t" + c.getCpass());
		}

	}

	// Purchas Food Iteam

	public void AddPurchasFoodIteam() {

		int ch;
		do {
			System.out.println(" 1. To Purchase Food Iteam");
			System.out.println("0. TO Complete Ordera");
			System.out.println("Enter your Choice");
			ch = sc.nextInt();

			switch (ch) {

			case 1:
				System.out.println("Enter the Food id");
				int fid = sc.nextInt();
				System.out.println("Enter the food quantity");
				int fqty = sc.nextInt();

				for (Object obj : al) {
					int bill = 0;

					Food f = (Food) obj;
					if (fid == f.getId()) {
						bill = f.getPrice() * fqty;

					}
					Tbill = Tbill + bill;

				}

				break;

			}

		} while (ch != 0);

	}

	// Display Total Bill

	public void TotalBill() {
		System.out.println("Total Bill is :" + Tbill);
		BillColl.add(Tbill);

	}

	// Serach Food Iteam Between Price Range
	public void PriceRangeFood() {

		System.out.println("Strat Range for food ");
		int S = sc.nextInt();

		System.out.println("End Range For Food");
		int E = sc.nextInt();
		for (Object obj : al) {
			Food f = (Food) obj;
			if (f.getPrice() >= S && f.getPrice() <= E) {
				System.out.println(c.getCid() + "\t" + c.getCname() + "\t" + c.getCconatact() + "\t" + c.getCpass());
			}

		}

	}

	// Serach Food Iteam By Categary

	public void FoodIteamCategary() {

		System.out.println("Enter to Categary to Sreach Food :");
		String cat = sc.next();
		System.out.println("Id" + "\t" + "Name" + "\t" + "Price" + "\t");

		for (Object obj : al) {
			Food f = (Food) obj;

			if (cat.equals(f.getCategory())) {

				System.out.println(f.getId() + "\t" + f.getName() + "\t" + f.getPrice());

			}

		}

	}

}
